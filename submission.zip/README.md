# proyek_analisis_data
 proyek dari materi analisis data


# Bike Sharing Dashboard

# Setup Enviroment Google Colab
1.buka google colab

2.buat file google colab baru

3.ubah nama menjadi: proyek_analisis_data

# Setup Dashboard
```
pip install -r requirements.txt
```

```
import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
```

# Run Streamlit App
```
streamlit run dashboard/proyek_analisis_data.py
```
